import sqlite3
from datetime import datetime
import bcrypt, os

DB = 'blackjack_casino.db'

def init_db():
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash BLOB NOT NULL
    )''')
    cur.execute('''CREATE TABLE IF NOT EXISTS results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        player_score INTEGER,
        dealer_score INTEGER,
        result TEXT,
        timestamp TEXT
    )''')
    conn.commit()
    conn.close()

def signup():
    init_db()
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    username = input('Choose username: ').strip()
    if not username:
        print('Username cannot be empty.')
        conn.close()
        return None
    cur.execute('SELECT id FROM users WHERE username=?', (username,))
    if cur.fetchone():
        print('Username exists.')
        conn.close()
        return None
    password = input('Choose password: ').encode('utf-8')
    hashed = bcrypt.hashpw(password, bcrypt.gensalt())
    cur.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, hashed))
    conn.commit()
    conn.close()
    print('Signup complete.')

def login_console():
    init_db()
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    username = input('Username: ').strip()
    password = input('Password: ').encode('utf-8')
    cur.execute('SELECT id, password_hash FROM users WHERE username=?', (username,))
    row = cur.fetchone()
    conn.close()
    if row and bcrypt.checkpw(password, row[1]):
        print('Login ok.')
        return row[0], username
    print('Login failed.')
    return None, None

def save_result(user_id, player_score, dealer_score, result):
    init_db()
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    ts = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
    cur.execute('INSERT INTO results (user_id, player_score, dealer_score, result, timestamp) VALUES (?, ?, ?, ?, ?)', 
                (user_id, player_score, dealer_score, result, ts))
    conn.commit()
    conn.close()

def fetch_history(user_id):
    init_db()
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute('SELECT player_score, dealer_score, result, timestamp FROM results WHERE user_id=? ORDER BY id DESC', (user_id,))
    rows = cur.fetchall()
    conn.close()
    return rows
