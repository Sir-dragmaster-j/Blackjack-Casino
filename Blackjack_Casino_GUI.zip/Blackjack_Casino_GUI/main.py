import customtkinter as ctk
from PIL import Image, ImageTk, ImageDraw, ImageFont
import os, pathlib
from database import init_db, signup, login_console, save_result, fetch_history
from blackjack_logic import new_deck, score, is_blackjack, play_round

ASSETS = os.path.join(os.path.dirname(__file__), 'assets')
CARDS_DIR = os.path.join(ASSETS, 'cards')

ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('dark-blue')

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title('Blackjack Casino - Black & Gold')
        self.geometry('960x640')
        self.configure(fg_color='#0d0d0d')

        init_db()

        # frames
        self.frames = {}
        for F in (LoginFrame, MenuFrame, GameFrame, HistoryFrame):
            page_name = F.__name__
            frame = F(parent=self, controller=self)
            self.frames[page_name] = frame
            frame.place(relx=0, rely=0, relwidth=1, relheight=1)

        self.show_frame('LoginFrame')
        self.user_id = None
        self.username = None

    def show_frame(self, name):
        frame = self.frames[name]
        frame.tkraise()

class LoginFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(fg_color='#0d0d0d')
        # title
        title = ctk.CTkLabel(self, text='BLACKJACK CASINO', text_color='#d4af37', font=ctk.CTkFont(size=28, weight='bold'))
        title.pack(pady=30)
        # username
        self.username_entry = ctk.CTkEntry(self, placeholder_text='Username', width=240)
        self.username_entry.pack(pady=10)
        self.password_entry = ctk.CTkEntry(self, placeholder_text='Password', show='*', width=240)
        self.password_entry.pack(pady=10)
        # buttons frame
        btn_frame = ctk.CTkFrame(self, fg_color='transparent')
        btn_frame.pack(pady=10)
        login_btn = ctk.CTkButton(btn_frame, text='Login', width=100, fg_color='#d4af37', command=self.login)
        signup_btn = ctk.CTkButton(btn_frame, text='Signup', width=100, fg_color='#d4af37', command=self.signup)
        login_btn.grid(row=0, column=0, padx=8)
        signup_btn.grid(row=0, column=1, padx=8)

        self.msg = ctk.CTkLabel(self, text='', text_color='white')
        self.msg.pack(pady=8)

    def login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        # use console login for now (reusing function)
        # but we will use DB calls directly for GUI in real scenario
        import sqlite3, bcrypt
        conn = sqlite3.connect('blackjack_casino.db')
        cur = conn.cursor()
        cur.execute('SELECT id, password_hash FROM users WHERE username=?', (username,))
        row = cur.fetchone()
        conn.close()
        if not row:
            self.msg.configure(text='User not found.', text_color='#ff5555')
            return
        user_id, p_hash = row
        if bcrypt.checkpw(password.encode('utf-8'), p_hash):
            self.controller.user_id = user_id
            self.controller.username = username
            self.msg.configure(text='Login successful!', text_color='#a8ff7f')
            self.after(700, lambda: self.controller.show_frame('MenuFrame'))
        else:
            self.msg.configure(text='Incorrect password.', text_color='#ff5555')

    def signup(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        if not username or not password:
            self.msg.configure(text='Enter username and password.', text_color='#ff5555')
            return
        import sqlite3, bcrypt
        conn = sqlite3.connect('blackjack_casino.db')
        cur = conn.cursor()
        cur.execute('SELECT id FROM users WHERE username=?', (username,))
        if cur.fetchone():
            self.msg.configure(text='Username exists.', text_color='#ff5555')
            conn.close()
            return
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        cur.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, hashed))
        conn.commit()
        conn.close()
        self.msg.configure(text='Signup success. You can login.', text_color='#a8ff7f')

class MenuFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(fg_color='#0d0d0d')
        lbl = ctk.CTkLabel(self, text='Main Menu', text_color='#d4af37', font=ctk.CTkFont(size=24, weight='bold'))
        lbl.pack(pady=30)
        play_btn = ctk.CTkButton(self, text='Play Blackjack', width=200, fg_color='#d4af37', command=lambda: controller.show_frame('GameFrame'))
        hist_btn = ctk.CTkButton(self, text='View History', width=200, fg_color='#d4af37', command=lambda: controller.show_frame('HistoryFrame'))
        logout_btn = ctk.CTkButton(self, text='Logout', width=200, fg_color='#d4af37', command=self.logout)
        play_btn.pack(pady=8); hist_btn.pack(pady=8); logout_btn.pack(pady=8)

    def logout(self):
        self.controller.user_id = None
        self.controller.username = None
        self.controller.show_frame('LoginFrame')

class GameFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(fg_color='#0d0d0d')
        # top: dealer
        self.dealer_label = ctk.CTkLabel(self, text='Dealer', text_color='white', font=ctk.CTkFont(size=18))
        self.dealer_label.pack(pady=8)
        self.dealer_canvas = ctk.CTkCanvas(self, width=800, height=120, bg='#0d0d0d', highlightthickness=0)
        self.dealer_canvas.pack()
        # middle: table area
        self.table = ctk.CTkFrame(self, fg_color='#101010')
        self.table.pack(pady=10, ipady=10, padx=20, fill='x')
        # bottom: player
        self.player_label = ctk.CTkLabel(self, text='Player', text_color='white', font=ctk.CTkFont(size=18))
        self.player_label.pack(pady=8)
        self.player_canvas = ctk.CTkCanvas(self, width=800, height=160, bg='#0d0d0d', highlightthickness=0)
        self.player_canvas.pack()

        # action buttons
        btn_frame = ctk.CTkFrame(self, fg_color='transparent')
        btn_frame.pack(pady=10)
        self.hit_btn = ctk.CTkButton(btn_frame, text='Hit', width=120, fg_color='#d4af37', command=self.hit)
        self.stand_btn = ctk.CTkButton(btn_frame, text='Stand', width=120, fg_color='#d4af37', command=self.stand)
        self.back_btn = ctk.CTkButton(btn_frame, text='Back to Menu', width=120, fg_color='#d4af37', command=lambda: controller.show_frame('MenuFrame'))
        self.hit_btn.grid(row=0, column=0, padx=8); self.stand_btn.grid(row=0, column=1, padx=8); self.back_btn.grid(row=0, column=2, padx=8)

        self.deck = []
        self.player = []
        self.dealer = []

        self.load_images()

    def load_images(self):
        # try to preload card images; if missing, will draw placeholders
        self.card_images = {}
        if not os.path.isdir(CARDS_DIR):
            return
        for fname in os.listdir(CARDS_DIR):
            if fname.lower().endswith('.png'):
                key = os.path.splitext(fname)[0]  # e.g. 'AH'
                try:
                    img = Image.open(os.path.join(CARDS_DIR, fname)).resize((80,120), Image.LANCZOS)
                    self.card_images[key] = ImageTk.PhotoImage(img)
                except Exception as e:
                    pass

    def draw_card_image(self, canvas, x, y, code):
        # try to draw actual image; else draw rectangle with text
        key = code
        if key in self.card_images:
            canvas.create_image(x, y, image=self.card_images[key], anchor='nw')
        else:
            # draw placeholder rectangle with gold border
            canvas.create_rectangle(x, y, x+80, y+120, fill='#111111', outline='#d4af37', width=2)
            canvas.create_text(x+40, y+60, text=code, fill='white', font=('Arial', 16, 'bold'))

    def start_round(self):
        self.deck = new_deck()
        self.player = [self.deck.pop(), self.deck.pop()]
        self.dealer = [self.deck.pop(), self.deck.pop()]
        self.render()

# rest of GameFrame methods left out in this file for brevity - full code available in zip
