Blackjack Casino - Black & Gold GUI (Desktop)
--------------------------------------------------
What this package contains:
- main.py            -> Tkinter GUI (CustomTkinter)
- blackjack_logic.py -> Game logic (deck, scoring)
- database.py        -> SQLite signup/login/history
- requirements.txt   -> python packages: customtkinter, bcrypt, pillow
- assets/cards/      -> place 52 card images here (PNG) named like: AH.png, 2H.png, ..., KS.png
                      (A = Ace, J,Q,K for face cards; suits: H, D, C, S)
- assets/bg.png      -> optional background image (not included)
- assets/logo.png    -> optional logo (not included)

Important:
- I could not include realistic card images due to environment limits. 
- To enable graphical cards, download any standard 52-card PNG pack and put files in assets/cards/.
  Recommended naming: 'AH.png' (Ace of Hearts), '10D.png', 'JS.png', 'QC.png', etc.
- The GUI will gracefully fall back to drawn rectangles when card images are missing.

How to run:
1. Create virtualenv and activate it:
   python -m venv venv
   venv\Scripts\activate   (Windows) or source venv/bin/activate (Mac/Linux)
2. Install dependencies:
   pip install -r requirements.txt
3. Run:
   python main.py
