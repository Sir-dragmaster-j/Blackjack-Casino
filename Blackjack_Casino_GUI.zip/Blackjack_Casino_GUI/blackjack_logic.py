import random

RANKS = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
SUITS = ['H','D','C','S']  # Hearts, Diamonds, Clubs, Spades

def new_deck():
    deck = []
    for s in SUITS:
        for r in RANKS:
            deck.append(f"{r}{s}")  # e.g. 'AH', '10D', 'KS'
    random.shuffle(deck)
    return deck

def card_value(rank):
    if rank in ['J','Q','K']:
        return 10
    if rank == 'A':
        return 11
    return int(rank)

def score(hand):
    total = 0
    aces = 0
    for code in hand:
        # code like 'AH' -> rank = code[:-1]
        rank = code[:-1]
        if rank in ['J','Q','K']:
            total += 10
        elif rank == 'A':
            total += 11
            aces += 1
        else:
            total += int(rank)
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total

def is_blackjack(hand):
    return len(hand) == 2 and score(hand) == 21

def play_round(deck, player_hand, dealer_hand):
    # returns final hands and result
    # player_hand and dealer_hand are lists of card codes
    # assume player's actions done outside: this function for dealer resolution
    while score(dealer_hand) < 17:
        dealer_hand.append(deck.pop())
    p = score(player_hand)
    d = score(dealer_hand)
    if d > 21 or p > d:
        return player_hand, dealer_hand, 'WIN'
    if p == d:
        return player_hand, dealer_hand, 'DRAW'
    return player_hand, dealer_hand, 'LOSS'
